import Foundation
/*:
 ## Struct Lab - Tuwaiq Bootcamp

 Create a struct called Book that contains the following properties:

 - title: a String representing the title of the book
 - author: a String representing the author of the book
 - pages: an integer representing the number of pages in the book
 - topic: a String representing the topic or genre of the book (e.g. Computer Science, Programming, Self-Development, etc.)
 
 */
struct Book{
    var title : String
    var author : String
    var pages : Int
    var topic : String
    
    init(title : String, author : String , pages : Int , topic : String){
        self.title = title
        self.author = author
        self.pages = pages
        self.topic = topic
        
    }
}
/*:
 Create an array of type Book and populate it with at least 3 books using a loop.
 */
var myArrar : [Book] = [Book(title: "The book Thief", author: "Markus Zusak", pages: 560, topic: "History"),
                        Book(title: "A Good Girl'S Guide To Murder", author: "Holly Jackson ", pages: 448, topic: "adventure"),
                        Book(title: "It Ends With Us", author: "Colleen Hoover ", pages: 384, topic: "romantic")]



// here i try to add the element using array and i have some errors so add thin in the array the error in line 43

//for i in 1...myArrar.count {
//    var titles : [String] = ["The book Thief","A Good Girl'S Guide To Murder","It Ends With Us"]
//    var authors : [String] = ["Markus Zusak","Holly Jackson ","Colleen Hoover "]
//    var page : [Int] = [560 ,448 , 384]
//    var topices : [String] = ["History","adventure" , "romantic"]
//    myArrar.append(Book(title: titles[i], author: authors[i], pages: page[i], topic: topices[i]))
//}
//print(myArrar[1])





/*:
 Then, write a function called printBooksInTopic that takes two arguments: the array of books and a topic as a String. The function should print out the title and author of each book in the array that matches the specified topic.
 */
func printBooksInTopic(  books : Book  , topic:String ){
    if books.topic == topic {
        print("the author for the book is : \(books.author) and the title is \(books.title)")
    } else {
        print("thay did not match!")
    }
}
printBooksInTopic(books: Book(title: "The book Thief", author: "Markus Zusak", pages: 560, topic: "History"), topic: "History")



// Example usage:
// printBooksInTopic(books, topic: "Programming")

// Example usage:
//printBooksInTopic(books, topic: "Programming")

//Output
/*
 Clean Code: A Handbook of Agile Software Craftsmanship by Robert C. Martin
 Cracking the Coding Interview: 189 Programming Questions and Solutions by Gayle Laakmann McDowell
 */
